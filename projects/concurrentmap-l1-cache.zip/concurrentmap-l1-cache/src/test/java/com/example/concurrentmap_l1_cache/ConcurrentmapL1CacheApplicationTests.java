package com.example.concurrentmap_l1_cache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcurrentmapL1CacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
