package com.example.concurrentmap_l1_cache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConcurrentmapL1CacheApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConcurrentmapL1CacheApplication.class, args);
	}

}
